﻿[CmdletBinding()] 
Param (
    [string]$aduser,
    [string]$adpassword,
    [string]$ou,
    [string]$upn
)

 $LogFile1 = ("AD-Account-Creation-{0:yyyy-MM-dd-HH-mm-ss}.log" -f (Get-Date)) 
 $Log1 = "c:\ExtendAD\scripts\$LogFile1" 
 Start-Transcript $Log1

 Start-Sleep -Seconds 5
 
 Import-Module ActiveDirectory

 #Create OUs
 New-ADOrganizationalUnit -Name LabData -Path "$ou"
 $LabDataOU = "ou=LabData," + "$ou"
 New-ADOrganizationalUnit -Name UserAccounts -Path "$LabDataOU"
 $UserOU = "ou=UserAccounts," + "$LabDataOU"
 New-ADOrganizationalUnit -Name Groups -Path "$LabDataOU"
 $GroupsOU = "ou=Groups," + "$LabDataOU"

 #Create Groups
 $GroupCsv = Import-Csv -Path c:\ExtendAD\scripts\ad-group-data.csv
    ForEach ($Group in $GroupCsv) 
    { 
        $Gsam = $Group.SAM 
        $GDescription = $Group.Description 
	             
        New-ADGroup -Name "$Gsam" -SamAccountName "$Gsam" -GroupCategory Security -GroupScope Global -DisplayName "$Gsam" -Path "$GroupsOU" -Description "$GDescription"
     } 
 
 
  #  Create User Accounts
	$UserCsv = Import-Csv -Path c:\ExtendAD\scripts\ad-user-data.csv
    ForEach ($User in $UserCsv) 
    { 
        $DisplayName = $User.Firstname + " " + $User.Lastname 
        $UserFirstName = $User.Firstname 
        $UserLastName = $User.Lastname 
        $Sam = $User.SAM 
        $adUpn = $Sam + "@$Upn" 
        $Description = $DisplayName 
        $Password = $User.Password 
	             
        New-ADUser -Name $Sam -DisplayName "$DisplayName" -SamAccountName $Sam -UserPrincipalName $adUpn -GivenName "$UserFirstName" -Surname "$UserLastName" -Description "$Description" -AccountPassword (ConvertTo-SecureString $Password -AsPlainText -Force) -Enabled $true -Path "$UserOU" -ChangePasswordAtLogon $true –PasswordNeverExpires $false -AccountExpirationDate $AdExpire -Verbose 
    } 


# Join Users to some groups
    ForEach ($User in $UserCsv)
    {
    $Group = $User.Group

    Add-ADGroupMember -Identity $Group -Member $User.SAM
    }

# Join Groups to some groups
    ForEach ($Group in $GroupCsv)
    {
    $GroupGroup = $Group.MemberOfGroup

    Add-ADGroupMember -Identity $GroupGroup -Member $Group.SAM
    }


# Assign Directory Permissions to users and groups


Stop-Transcript