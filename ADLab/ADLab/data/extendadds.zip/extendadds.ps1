﻿[CmdletBinding()] 
Param (
    [string]$ou,
    [string]$upn
)

 $LogFile1 = ("AD-Account-Creation-{0:yyyy-MM-dd-HH-mm-ss}.log" -f (Get-Date)) 
 $Log1 = "c:\ExtendAD\scripts\$LogFile1" 
 Start-Transcript $Log1
 
 Import-Module ActiveDirectory
 #New-ADUser -Name TestUser -DisplayName TestUser -SamAccountName TestUser -UserPrincipalName TestUser@contoso.com -GivenName Test -Surname User -Description TestUser -AccountPassword (ConvertTo-SecureString P@ssw0rd123456 -AsPlainText -Force) -Enabled $true -Path 'CN=Users,DC=contoso,DC=com' -ChangePasswordAtLogon $true –PasswordNeverExpires $false -AccountExpirationDate $AdExpire -Verbose 

  #  $UserCsv = Import-Csv -Path "$UsersList" 
	$UserCsv = Import-Csv -Path c:\ExtendAD\scripts\ad-data.csv
    ForEach ($User in $UserCsv) 
    { 
        $DisplayName = $User.Firstname + " " + $User.Lastname 
        $UserFirstName = $User.Firstname 
        $UserLastName = $User.Lastname 
        $Sam = $User.SAM 
        $adUpn = $Sam + "@$Upn" 
        $Description = $DisplayName 
        $Password = $User.Password 
	             
        New-ADUser -Name $Sam -DisplayName "$DisplayName" -SamAccountName $Sam -UserPrincipalName $adUpn -GivenName "$UserFirstName" -Surname "$UserLastName" -Description "$Description" -AccountPassword (ConvertTo-SecureString P@ssw0rd123456 -AsPlainText -Force) -Enabled $true -Path "$ou" -ChangePasswordAtLogon $true –PasswordNeverExpires $false -AccountExpirationDate $AdExpire -Verbose 
        # New-ADUser -Name "$Sam" -DisplayName "$DisplayName" -SamAccountName "$Sam" -UserPrincipalName "$adUpn" -GivenName "$UserFirstName" -Surname "$UserLastName" -Description TestUser -AccountPassword (ConvertTo-SecureString P@ss0rd123456 -AsPlainText -Force) -Enabled $true -Path 'CN=Users,DC=contoso,DC=com' -ChangePasswordAtLogon $true –PasswordNeverExpires $false -Verbose 
    } 

Stop-Transcript