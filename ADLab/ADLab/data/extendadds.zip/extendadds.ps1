﻿[CmdletBinding()] 
Param (
    [string]$aduser,
    [string]$adpassword,
    [string]$ou,
    [string]$upn
)

 $LogFile1 = ("AD-Account-Creation-{0:yyyy-MM-dd-HH-mm-ss}.log" -f (Get-Date)) 
 $Log1 = "c:\ExtendAD\scripts\$LogFile1" 
 Start-Transcript $Log1

 Start-Sleep -Seconds 5
 
 Import-Module ActiveDirectory

 #Create OUs
 New-ADOrganizationalUnit -Name LabData -Path "$ou"
 $LabDataOU = "ou=LabData," + "$ou"
 New-ADOrganizationalUnit -Name UserAccounts -Path "$LabDataOU"
 $UserOU = "ou=UserAccounts," + "$LabDataOU"
 New-ADOrganizationalUnit -Name Groups -Path "$LabDataOU"
 $GroupsOU = "ou=Groups," + "$LabDataOU"

 #Create Groups
 $GroupCsv = Import-Csv -Path c:\ExtendAD\scripts\ad-group-data.csv
    ForEach ($Group in $GroupCsv) 
    { 
        $Gsam = $Group.SAM 
        $GDescription = $Group.Description 
	             
        New-ADGroup -Name "$Gsam" -SamAccountName "$Gsam" -GroupCategory Security -GroupScope Global -DisplayName "$Gsam" -Path "$GroupsOU" -Description "$GDescription" -Verbose
     } 
 
 
  #  Create User Accounts
	$UserCsv = Import-Csv -Path c:\ExtendAD\scripts\ad-user-data.csv
    ForEach ($User in $UserCsv) 
    { 
        $DisplayName = $User.Firstname + " " + $User.Lastname 
        $UserFirstName = $User.Firstname 
        $UserLastName = $User.Lastname 
        $Sam = $User.SAM 
        $adUpn = $Sam + "@$Upn" 
        $Description = $DisplayName 
        $Password = $User.Password 
	             
        New-ADUser -Name $Sam -DisplayName "$DisplayName" -SamAccountName $Sam -UserPrincipalName $adUpn -GivenName "$UserFirstName" -Surname "$UserLastName" -Description "$Description" -AccountPassword (ConvertTo-SecureString $Password -AsPlainText -Force) -Enabled $true -Path "$UserOU" -ChangePasswordAtLogon $true –PasswordNeverExpires $false -AccountExpirationDate $AdExpire -Verbose 
    } 


# Join Users to some groups
    ForEach ($User in $UserCsv)
    {
    $Group = $User.Group

    Add-ADGroupMember -Identity $Group -Members $User.SAM -Verbose
    }

# Join Groups to some groups
    ForEach ($Group in $GroupCsv)
    {
    $GroupGroup = $Group.MemberOfGroup

    Add-ADGroupMember -Identity $GroupGroup -Members $Group.SAM -Verbose
    }


# Assign Directory Permissions to users and groups
        cd ad:

    #Get a reference to the RootDSE of the current domain
        $rootdse = Get-ADRootDSE
    #Get a reference to the current domain
        $domain = Get-ADDomain

    #Create a hashtable to store the GUID value of each schema class and attribute
        $guidmap = @{}
        Get-ADObject -SearchBase ($rootdse.SchemaNamingContext) -LDAPFilter `
        "(schemaidguid=*)" -Properties lDAPDisplayName,schemaIDGUID | 
        % {$guidmap[$_.lDAPDisplayName]=[System.GUID]$_.schemaIDGUID}

    #Create a hashtable to store the GUID value of each extended right in the forest
        $extendedrightsmap = @{}
        Get-ADObject -SearchBase ($rootdse.ConfigurationNamingContext) -LDAPFilter `
        "(&(objectclass=controlAccessRight)(rightsguid=*))" -Properties displayName,rightsGuid | 
        % {$extendedrightsmap[$_.displayName]=[System.GUID]$_.rightsGuid}

    #Get a reference to the OU we want to delegate
       # $p_ou = Get-ADOrganizationalUnit -Identity ("OU=UserAccounts,"+$domain.DistinguishedName)
        $p_ou = Get-ADOrganizationalUnit -Identity $UserOU
    #Get the SID values of each group we wish to delegate access to
        $p = New-Object System.Security.Principal.SecurityIdentifier (Get-ADGroup "Group17").SID
        $s = New-Object System.Security.Principal.SecurityIdentifier (Get-ADGroup "Group24").SID
    #Get a copy of the current DACL on the OU
        $acl = Get-ACL -Path ($p_ou.DistinguishedName)
    #Create an Access Control Entry for new permission we wish to add
    #Allow the group to write all properties of descendent user objects
        $acl.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule `
        $p,"WriteProperty","Allow","Descendents",$guidmap["user"]))
    #Allow the group to create and delete user objects in the OU and all sub-OUs that may get created
        $acl.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule `
        $p,"CreateChild,DeleteChild","Allow",$guidmap["user"],"All"))
    #Allow the group to reset user passwords on all descendent user objects
        $acl.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule `
        $p,"ExtendedRight","Allow",$extendedrightsmap["Reset Password"],"Descendents",$guidmap["user"]))
    #Allow the Service Desk group to also reset passwords on all descendent user objects
        $acl.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule `
        $s,"ExtendedRight","Allow",$extendedrightsmap["Reset Password"],"Descendents",$guidmap["user"]))
    #Re-apply the modified DACL to the OU
        Set-ACL -ACLObject $acl -Path ("AD:\"+($p_ou.DistinguishedName))

    #Provision the Group Policy Admins role
        $acl = Get-ACL -Path ($rootdse.defaultNamingContext)
        $g = New-Object System.Security.Principal.SecurityIdentifier (Get-ADGroup ("Group29")).SID
        $acl.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule `
        $g,"WriteProperty","Allow",$guidmap["gplink"],"All"))
        $acl.AddAccessRule((New-Object System.DirectoryServices.ActiveDirectoryAccessRule `
        $g,"WriteProperty","Allow",$guidmap["gpoptions"],"All"))
        Set-ACL -ACLObject $acl -Path ("AD:\"+($rootdse.defaultNamingContext))

Stop-Transcript